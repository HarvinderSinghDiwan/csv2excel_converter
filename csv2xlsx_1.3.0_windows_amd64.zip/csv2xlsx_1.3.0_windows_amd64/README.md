# csv2xlsx
Convert csv file to xlsx.

## Usage

1. Convert specified csv file to xlsx:
```bash
csv2xlsx csvFile
```

2. Convert all csv files in the folder to xlsx:
```bash
csv2xlsx
```

## Download
[https://github.com/nadoo/csv2xlsx/releases](https://github.com/nadoo/csv2xlsx/releases "click to the download page")